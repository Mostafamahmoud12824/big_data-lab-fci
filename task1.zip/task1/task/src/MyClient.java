import java.io.*;
import java.net.*;

public class MyClient {
    public static void main(String[] args) {
        try{
            Socket s=new Socket("localhost",6666);
            DataOutputStream dout=new DataOutputStream(s.getOutputStream());
            int m = 2;
            int n = 1;
            int matrix[][] = new int [m][n];
            matrix[0][0] = 2;
            matrix[1][0] = 2;
            dout.writeInt(m);
            dout.writeInt(n);
            for (int i = 0; i < m; i++) {
                for (int j = 0; j < n; j++) {
                    dout.writeInt(matrix[i][j]);
                }
            }
            dout.flush();
            dout.close();
            s.close();
        }catch(Exception e){System.out.println(e);}
    }
}