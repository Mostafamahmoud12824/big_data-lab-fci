import java.io.*;
import java.net.*;
public class MyServer {
    public static void main(String[] args){
        try{
            ServerSocket ss=new ServerSocket(6666);
            Socket s=ss.accept();//establishes connection
            DataInputStream dis=new DataInputStream(s.getInputStream());
            int m=dis.readInt();
            int n=dis.readInt();
            int matrix1[][] = new int [m][n];
            for (int i = 0; i < m; i++) {
                for (int j = 0; j < n; j++) {
                    matrix1[i][j] = dis.readInt();
                }
            }
            ss.close();
            ServerSocket ss2=new ServerSocket(6665);
            Socket s2=ss2.accept();//establishes connection
            DataInputStream dis2=new DataInputStream(s2.getInputStream());
            int m2=dis2.readInt();
            int n2=dis2.readInt();

            int matrix2[][] = new int [m2][n2];
            for (int i = 0; i < m2; i++) {
                for (int j = 0; j < n2; j++) {
                    matrix2[i][j] = dis2.readInt();
                }
            }

            if (n==m2){
                int result [][] = new int[m][n2];
                for (int i = 0; i < m; i++) {
                    for (int j = 0; j < n2; j++) {
                        for (int k = 0; k < m2; k++)
                            result[i][j] += matrix1[i][k] * matrix2[k][j];
                    }
                }
                System.out.print("[");
                for (int i = 0; i < m; i++) {

                    for (int j = 0; j < n2; j++) {
                        System.out.print(" "+result[i][j]+" ");
                    }
                    if(i!=m-1)
                    System.out.print("\n");
                }
                System.out.print("]");
            }

            else{
                System.out.println("Cannot Multiple This Two Matrix !...");
            }
            ss2.close();
        }catch(Exception e){System.out.println(e);}
    }
}
